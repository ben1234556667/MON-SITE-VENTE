
document.querySelector('form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Message envoyé ! (fonctionnement fictif)');
});
